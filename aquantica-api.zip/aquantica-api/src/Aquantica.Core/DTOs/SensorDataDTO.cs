namespace Aquantica.Core.DTOs;

public class SensorDataDTO
{
    public double Humidity { get; set; }
    public double Temperature { get; set; }
}