namespace Aquantica.Core.DTOs;

public class ArduinoResponseDTO
{
    public bool IsSuccess { get; set; }
    
}