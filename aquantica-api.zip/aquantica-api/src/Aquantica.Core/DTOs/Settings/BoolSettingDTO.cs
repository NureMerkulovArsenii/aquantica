namespace Aquantica.Core.DTOs.Settings;

public class BoolSettingDTO : SettingDTO
{
    public bool Value { get; set; }
}