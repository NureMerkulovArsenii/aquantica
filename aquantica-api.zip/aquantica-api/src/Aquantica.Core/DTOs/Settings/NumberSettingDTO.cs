namespace Aquantica.Core.DTOs.Settings;

public class NumberSettingDTO : SettingDTO
{
    public int Value { get; set; }
}