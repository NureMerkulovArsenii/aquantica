namespace Aquantica.Core.DTOs.Settings;

public class StringSettingDTO : SettingDTO
{
    public string ValueType { get; set; }
    public string Value { get; set; }
}