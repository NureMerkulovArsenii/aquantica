namespace Aquantica.Core.Constants;

public static class JobConstants
{
    public const string JOB_STARTED_MESSAGE = "Start";
    public const string JOB_FINISHED_MESSAGE = "Finish";
    public const string JOB_ERROR_MESSAGE = "Error";
}