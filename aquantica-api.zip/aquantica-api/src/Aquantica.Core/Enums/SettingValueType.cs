namespace Aquantica.Core.Enums;

public enum SettingValueType
{
    Number = 1,
    String = 2,
    Boolean = 3,
    DateTime = 4,
}