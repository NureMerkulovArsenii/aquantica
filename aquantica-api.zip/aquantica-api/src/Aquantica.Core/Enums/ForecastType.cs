namespace Aquantica.Core.Enums;

public enum ForecastType
{
    Full = 0,
    
}