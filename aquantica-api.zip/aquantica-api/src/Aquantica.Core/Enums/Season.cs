namespace Aquantica.Core.Enums;

public enum Season
{
    Spring,
    Summer,
    Autumn,
    Winter
}