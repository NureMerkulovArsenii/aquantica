namespace Aquantica.Core.Enums;

public enum JobMethodEnum
{
    GetWeatherForecast = 1,
    StartIrrigation = 2,
    StopIrrigation = 3,
    CollectSensorData = 4,
    
}