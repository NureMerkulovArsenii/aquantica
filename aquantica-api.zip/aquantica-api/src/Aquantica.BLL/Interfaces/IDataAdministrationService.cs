namespace Aquantica.BLL.Interfaces;

public interface IDataAdministrationService
{
    Task CreateDataBaseBackupAsync();
}