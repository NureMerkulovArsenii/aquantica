﻿namespace Aquantica.BLL;

public static class AssemblyRunner
{

}
