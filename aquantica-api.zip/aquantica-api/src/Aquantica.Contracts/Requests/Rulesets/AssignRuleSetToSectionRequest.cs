namespace Aquantica.Contracts.Requests.Rulesets;

public class AssignRuleSetToSectionRequest
{
    public int RuleSetId { get; set; }
    public int SectionId { get; set; }
}