﻿namespace Aquantica.Contracts.Responses.User;

public class AuthResponse
{
    public int UserId { get; set; }
    public string AccessToken { get; set; }
}
