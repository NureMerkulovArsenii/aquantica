﻿namespace Aquantica.DAL;

public static class AssemblyRunner
{

}
